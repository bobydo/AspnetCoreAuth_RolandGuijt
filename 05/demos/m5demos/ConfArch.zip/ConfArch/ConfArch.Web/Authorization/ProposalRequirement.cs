﻿using Microsoft.AspNetCore.Authorization;

namespace ConfArch.Web.Authorization
{
    public class ProposalRequirement : IAuthorizationRequirement
    {
    }
}
